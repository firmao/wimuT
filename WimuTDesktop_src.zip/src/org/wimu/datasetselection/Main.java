package org.wimu.datasetselection;

import java.util.Set;

public class Main {

	public static void main(String[] args) {
		long start = System.currentTimeMillis(); 
		//Set<String> setQueries = Util.getSampleQueries("/home/andre/queries.txt");
		Set<String> setQueries = Util.getSampleQueries("queries.txt");
		System.out.println("Number of queries: " + setQueries.size());
		Set<WimuTQuery> res = Util.executeAllQueries(setQueries);
		Util.writeFile(res, "results.tsv");
		long totalTime = System.currentTimeMillis() - start;
		System.out.println("Total Time (ms): " + totalTime);
	}
}
