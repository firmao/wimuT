package org.wimu.datasetselection;

import java.util.Set;

public class Main {

	public static void main(String[] args) {
		long start = System.currentTimeMillis(); 
		//Set<String> setQueries = Util.getSampleQueries("/home/andre/queries.txt");
		
		String file = args[0];
		Set<String> setQueries = Util.getSampleQueries(file);
		System.out.println("File with the queries: " + file);
		System.out.println("######## Number of queries: "+setQueries.size());
		
		System.out.println("Number of queries: " + setQueries.size());
		Set<WimuTQuery> res = null;
		if(args[1].equals("all")){
			res = Util.executeAllQueries(setQueries);
		} else if(args[1].equals("squin")){
			res = Util.executeAllQueriesSquin(setQueries);
		} else if(args[1].equals("wimut")){
			res = Util.executeAllQueriesWimuT(setQueries);
		}
		Util.writeFile(res, "results.tsv");
		long totalTime = System.currentTimeMillis() - start;
		System.out.println("Total Time (ms): " + totalTime);
	}
}
