package org.wimu.datasetselection;

import java.util.Set;

public class Main {

	public static void main(String[] args) {
		long start = System.currentTimeMillis(); 
		//Set<String> setQueries = Util.getSampleQueries("/home/andre/queries.txt");
		Set<String> setQueries = null;
		if(args[0].equals("test")){
			setQueries = Util.getSampleQueries("queries3.txt");
			System.out.println("######## only "+setQueries.size()+" queries ########");
		} else if(args[0].equals("normal")) {
			setQueries = Util.getSampleQueries("queries.txt");
		}
		
		System.out.println("Number of queries: " + setQueries.size());
		Set<WimuTQuery> res = null;
		if(args[1].equals("all")){
			res = Util.executeAllQueries(setQueries);
		} else if(args[1].equals("squin")){
			res = Util.executeAllQueriesSquin(setQueries);
		} else if(args[1].equals("wimut")){
			res = Util.executeAllQueriesWimuT(setQueries);
		}
		Util.writeFile(res, "results.tsv");
		long totalTime = System.currentTimeMillis() - start;
		System.out.println("Total Time (ms): " + totalTime);
	}
}
